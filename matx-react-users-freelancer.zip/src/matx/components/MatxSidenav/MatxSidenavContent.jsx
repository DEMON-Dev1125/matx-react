import React from "react";

const MatxSidenavContent = ({ children }) => {
  return <div className={`matx-sidenav-content h-100`}>{children}</div>;
};

export default MatxSidenavContent;
